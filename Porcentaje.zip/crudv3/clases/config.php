<?php
  /**
   * Este archivo tendra la informacion para nuestra conexion, usaremos constantes para esto
   */
    //Para nuestro servidor FTP
    define ('SERVIDOR', '13.2daw.esvirgua.com');
    define ('USUARIO', 'user2daw_13');
    define ('CONTRASENIA', 'k8D~R$8plhis');
    define ('BASEDATOS', 'user2daw_BD2-13'); 

    //PARA EL LOCALHOST
    // define ('SERVIDOR', 'localhost');
    // define ('USUARIO', 'root');
    // define ('CONTRASENIA', '');
    // define ('BASEDATOS', 'BDEMPLEADO');
?>